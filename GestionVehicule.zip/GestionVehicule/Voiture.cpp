#ifndef VOITURE_CPP
#define VOITURE_CPP


class Voiture : public Vehicule{
    public:
        Voiture();
        Voiture::Voiture(int port,int pl);
        virtual ~Voiture();
        Voiture(const Voiture& other);
        Voiture& operator=(const Voiture& other);

        int getPorts();
        void setPorts(int val);
        int getPlaces();
        void setPlaces(int val);

    protected:

    private:
        int ports;
        int places;
};

#endif // VOITURE_CPP

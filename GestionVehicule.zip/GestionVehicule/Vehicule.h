#include "Vehicule.cpp"

Vehicule::Vehicule()
{
    //ctor
    matricule = 0;
    marque = " ";
    couleur = " ";
}

Vehicule::~Vehicule()
{
    //dtor
}

Vehicule::Vehicule(int mat,String marq,string coul)
{
    matricule = mat;
    marque = marq;
    couleur = coul;
}
Vehicule::Vehicule(const Vehicule& other)
{
    //copy ctor
}
int getMatricule()
{
     return matricule;
}

void setMatricule(int val)
{
    matricule = val;
}

String getMarque()
{
    return marque;
}

void setMarque(String val)
{
    marque = val;
}

String getCouleur()
{
    return couleur;
}

void setCouleur(String val)
{
    couleur = val;
}

void sepresenter()
{

}


Vehicule& Vehicule::operator=(const Vehicule& rhs)
{
    if (this == &rhs) return *this; // handle self assignment
    //assignment operator
    return *this;
}

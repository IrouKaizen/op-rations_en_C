#include "Voiture.cpp"

Voiture::Voiture()
{
    //ctor
    ports = 0;
    places = 0;

}
 Voiture::Voiture(int port,int pl)
 {
     ports  = port;
     places = pl;
 }

int getPorts()
{
     return ports;
}

void setPorts(int val)
{
    ports = val;
}

int getPlaces()
{
     return places;
}

void setPlaces(int val)
{
    places = val;
}

Voiture::~Voiture()
{
    //dtor
}

Voiture::Voiture(const Voiture& other)
{
    //copy ctor
}

Voiture& Voiture::operator=(const Voiture& rhs)
{
    if (this == &rhs) return *this; // handle self assignment
    //assignment operator
    return *this;
}

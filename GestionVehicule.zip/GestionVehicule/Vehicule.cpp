#ifndef VEHICULE_CPP
#define VEHICULE_CPP
#include <String>


class Vehicule
{
    public:
        Vehicule();
        Vehicule::Vehicule(int mat,String marq,string coul);
        virtual ~Vehicule();
        Vehicule(const Vehicule& other);
        Vehicule& operator=(const Vehicule& other);

        int getMatricule();
        void setMatricule(int val);
        std::string getMarque();
        void setMarque(std::string val);
        std::string getCouleur();
        void setCouleur(std::string val);

    protected:

    private:
        int matricule;
        std::string marque;
        std::string couleur;
};

#endif // VEHICULE_CPP

#ifndef MOTO_CPP
#define MOTO_CPP


class Moto : public Vehicule
{
    public:
        Moto();
        Moto::Moto(int roue);
        virtual ~Moto();
        Moto(const Moto& other);
        Moto& operator=(const Moto& other);

        int getRoues();
        void setRoues(int val)

    protected:

    private:
        int roues;
};

#endif // MOTO_CPP

#include "Moto.h"

Moto::Moto()
{
    //ctor
    roues = 0;
}

Moto::Moto(int roue)
{
    roues = roue;
}
int getRoues()
{
    return roues;
}

void setRoues(int val)
{
    roues = val;
}

Moto::~Moto()
{
    //dtor
}

Moto::Moto(const Moto& other)
{
    //copy ctor
}

Moto& Moto::operator=(const Moto& rhs)
{
    if (this == &rhs) return *this; // handle self assignment
    //assignment operator
    return *this;
}
